void main() {
  final String nama = 'Budi Santoso'; 
  final String nim = '2024001'; 
  final int angkatan = 2024;
  bool aktif = true;

  print('Saya $nama, NIM $nim, angkatan $angkatan, status aktif: $aktif.');
}
